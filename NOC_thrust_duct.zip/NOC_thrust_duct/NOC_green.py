import numpy as np
import urllib
import json
import cv2
import os
import requests
import cv2
import sys
import pytesseract
import glob
import argparse
import csv

arg = argparse.ArgumentParser()
arg.add_argument("-f", "--filename", required=True, help="name of the file\nFile should be in the Input Direcctory")
arguments = vars(arg.parse_args())


def detect_api_object(file_name, file_output):
    image = cv2.imread(file_name)
    requests.packages.urllib3.disable_warnings()
    data = {"success": False}
    # print("check result")
    r = None

    api_url_arrow = "https://195.229.90.114/powerai-vision/api/dlapis/871af524-8fed-45c1-95b9-f42e0d51e1ac"
    with open(file_name, 'rb') as f:
        s = requests.Session()
        r = s.post(api_url_arrow, files={'files': (file_name, f), 'confthre': '0.8'}, verify=False, timeout=10)

    import os
    label_text = " "
    data = json.loads(r.text)
    print(data)
    testdata = data["classified"]

    duct_crossing = "duct crossing"

    for k, v in data.items():
        if v == duct_crossing:
            pass

    countofcropped = 0
    data_label = []
    for counter in range((len(testdata))):
        minX = int(testdata[counter].get('xmin'))  # (x1,y1,x2,y2)
        minY = int(testdata[counter].get('ymin'))
        maxX = int(testdata[counter].get('xmax'))
        maxY = int(testdata[counter].get('ymax'))

        croppedImage = image[maxY - 20:maxY + 320, minX + 30:maxX + 10]
        file_name_val = "crop" + os.sep + "Crop_" + str(countofcropped) + ".jpg"
        # print(file_name_val)
        cv2.imwrite(file_name_val, croppedImage)
        countofcropped += 1

        config = '-l eng --oem 1 --psm 3'

        im = cv2.imread(file_name_val)
        text = pytesseract.image_to_string(im, config=config)
        if len(text) > 30:
            text = text[0:30]
        data_label.append(text)
        label_text += text + "\n"

    api_url = "https://195.229.90.114/powerai-vision/api/dlapis/a6d8ce4b-9170-4905-92b3-66eca572d4d9"
    with open(file_name, 'rb') as f:
        s = requests.Session()
        r = s.post(api_url, files={'files': (file_name, f), 'confthre': '0.90'}, verify=False, timeout=10)
        # print(r.status_code)
        # print(r.text)

    import os
    thrust = 0
    duct = 0
    data = json.loads(r.text)
    testdata = data["classified"]
    # print('data', data)
    # print(testdata)

    countofcropped = 0
    # print("----->", len(testdata), type(data), type(testdata))

    for key in testdata:
        # print('key', key, type(key))
        for k, v in key.items():
            if k == 'label':
                if v.lower() == 'thrustblock':
                    thrust += 1
                if v.lower() == 'ductcrossing':
                    duct += 1

    created = False
    if os.path.isfile(file_output):
        created = True
    with open(file_output, "a") as res:
        writer = csv.writer(res)
        if not created:
            writer.writerow(["Labels detected in Image"])

        writer.writerow([data_label])

    print("converted successfully")
    print("status = 0")


file_input = arguments["filename"]
file_output = "output" + os.sep + "NOC_design_green.csv"
detect_api_object(file_input, file_output)
