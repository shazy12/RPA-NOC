import numpy as np
import urllib
import json
import cv2
import os
import requests
import cv2
import sys
import pytesseract
import glob
import argparse
import csv
from PIL import ImageFilter
from PIL import Image

extracted_number = []

arg = argparse.ArgumentParser()
arg.add_argument("-f", "--filename", required=True, help="name of the file\nFile should be in the Input Direcctory")
arguments = vars(arg.parse_args())


def extract_numbers(text):
    text = text.replace(" ", "")
    numbers = []
    for line in text:
        if line.isalpha() or line.isalnum() or line == ".":
            numbers.append(line.lower())
        else:
            pass
    text = ''.join([str(elem) for elem in numbers])
    text = "".join(text.split())
    # print("------------------", text, len(text))

    var_nohv = "nohv"
    var_nohv_length = len(var_nohv)
    var2x11 = "2x11kvcablecrossing"
    var2x11_length = len(var2x11)
    var1x11 = '1x11kvcablecrossing'
    var1x11_length = len(var1x11)
    var2x33 = '2x33kv1xpilotcrossing'
    var2x33_length = len(var2x33)
    var3x11 = '3x11kvcablecrossing'
    var3x11_length = len(var3x11)

    if var_nohv in text:
        # print("in nohv")
        text = text[var_nohv_length:]
        text1 = text.split(".")[0]
        text2 = text.split(".")[-1]
        text = text1+"."+text2[:2]

    elif var2x11 in text:
        # print("in var2x11")
        text = text[var2x11_length:]
        text1 = text.split(".")[0]
        text2 = text.split(".")[-1]
        text = text1 + "." + text2[:2]

    elif var1x11 in text:
        # print("in var1x11")
        text = text[var1x11_length:]
        text1 = text.split(".")[0]
        text2 = text.split(".")[-1]
        text = text1 + "." + text2[:2]

    elif var2x33 in text:
        # print("in var2x33")
        text = text[var2x33_length:]
        text1 = text.split(".")[0]
        text2 = text.split(".")[-1]
        text = text1 + "." + text2[:2]

    elif var3x11 in text:
        # print("in var3x11")
        text = text[var3x11_length:]
        text1 = text.split(".")[0]
        text2 = text.split(".")[-1]
        text = text1 + "." + text2[:2]

    if len(text) >= 1:
        return text
    else:
        return "no characters found"


def detect_api_object(file_name, file_output):
    image = cv2.imread(file_name)
    requests.packages.urllib3.disable_warnings()
    data = {"success": False}
    # print("check result")
    r = None

    # public ip
    api_url_arrow = "https://195.229.90.114/powerai-vision/api/dlapis/d7f389c4-2233-4514-9b29-7ff7f3027e83"

    # office use
    # api_url_arrow = "https://10.150.20.65/powerai-vision/api/dlapis/cdde0b97-1269-4743-b5d7-e4d4eb41fc55"

    # api_url_arrow = "https://10.150.20.61/powerai-vision/api/dlapis/e683ada5-6cd1-464a-a952-0229576d4a21"
    # api_url_arrow = "https://195.229.90.114/powerai-vision/api/dlapis/871af524-8fed-45c1-95b9-f42e0d51e1ac"
    with open(file_name, 'rb') as f:
        s = requests.Session()
        r = s.post(api_url_arrow, files={'files': (file_name, f), 'confthre': '0.8'}, verify=False, timeout=10)

    import os
    label_text = " "
    data = json.loads(r.text)
    # print(data)
    testdata = data["classified"]
    countofcropped = 0
    data_label = []
    data_text = ''
    for counter in range((len(testdata))):
        minX = int(testdata[counter].get('xmin'))  # (x1,y1,x2,y2)
        minY = int(testdata[counter].get('ymin'))
        maxX = int(testdata[counter].get('xmax'))
        maxY = int(testdata[counter].get('ymax'))

        if testdata[counter].get('label') == 'tp_box':
            # cv2.rectangle(image, (minX + 12, minY + 80), (maxX - 5, maxY + 5), (0, 255, 0), 2)
            croppedImage = image #[minY + 80:maxY + 5, minX + 12:maxX - 5]
            file_name_val = "crop\\Crop_" + str(countofcropped) + ".jpg"
            cv2.imwrite(file_name_val, croppedImage)
        else:
            if testdata[counter].get('label') == 'nohv':
                data_text =  'NO HV'
                minX = minX - 90
                maxX = maxX + 80
                maxY = maxY + 80
            elif testdata[counter].get('label') == '2x11kvcablecrossing':
                data_text = '2x11 kV Cable Crossing'
                # minX = minX - 100
                # maxX = maxX + 100
                maxY = maxY + 85
            elif testdata[counter].get('label') == '1X11CableCrossing':
                data_text = '1x11 Cable Crossing'
                # minX = minX - 100
                # maxX = maxX + 100
                maxY = maxY + 50
            elif testdata[counter].get('label') == '2x33kv1x11pilotcrossing':
                data_text = '3x11 kV Cable Crossing'   # to do for change label in power ai model and change label according to that
                # minX = minX - 100
                maxX = maxX + 90
                maxY = maxY + 50
            elif testdata[counter].get('label') == '3x11cablecrossing':
                data_text = '3x11 kV Cable Crossing'
                # minX = minX - 100
                # maxX = maxX + 100
                maxY = maxY - 10
            # cv2.rectangle(image, (minX, minY-2), (maxX, maxY), (0, 255, 0), 2)
            # cv2.rectangle(image, (minX + 30, maxY - 15), (maxX + 20, maxY + 320), (0, 255, 0), 2)
            croppedImage = image[minY:maxY, minX:maxX]
            file_name_val = "crop\\Crop_" + str(countofcropped) + ".jpg"
            cv2.imwrite(file_name_val, croppedImage)
            # croppedImage1 = Image.open(file_name_val)
            # croppedImage1 = croppedImage1.filter(ImageFilter.SHARPEN);
            # croppedImage = croppedImage1.filter(ImageFilter.SHARPEN);
            # croppedImage.save(file_name_val, 'JPEG')

        # cv2.imshow("before",croppedImage)
        # cv2.waitKey(0)

        # cv2.imwrite(file_name_val, croppedImage)

        config = '-l eng --oem 1 --psm 3'

        im = cv2.imread(file_name_val)
        # cv2.imshow("after", im)
        # cv2.waitKey(0)

        text = pytesseract.image_to_string(im, config=config)
        # print("output=", len(text), counter, text)
        # print("text(before function call)", text, "length\t", len(text))
        if testdata[counter].get('label') != 'tp_box':
            text_1 = extract_numbers(text)
            # print("text(after function call)", text_1)
            extracted_number.append(text_1)
        # print("extracted_number", extracted_number)
        if len(text) > 300:
            text = text[0:300]
        data_label.append(text)
        label_text += text + "\n"
        countofcropped += 1

    import os
    thrust = 0
    duct = 0
    data = json.loads(r.text)
    testdata = data["classified"]
    # print('data', data)
    # print(testdata)

    countofcropped = 0
    # print("----->", len(testdata), type(data), type(testdata))
    # print(file_name)
    search = "TRIAL PIT DETAILS"
    if file_name == "input/image2.jpg" or file_name == "input/image5.jpg":

        for i in data_label:
            # print("data in if", i)
            if search in i:
                idx = i.find(search)
                # print(idx)
                trialpit = i[idx + 19:idx + 24]
                # print("vlue", trialpit)

    else:
        for i in data_label:
            # print("data in else", i)
            if search in i:
                idx = i.find(search)
                # print(idx)
                trialpit = i[idx + 27:idx + 32]
                # print("vlue", trialpit)

    created = False
    if os.path.isfile(file_output):
        created = True
    with open(file_output, "a") as res:
        writer = csv.writer(res)
        if not created:
            writer.writerow(["file name", "Heading", "Distance", "Trial Pit", "Labels detected in Image"])

        # writer.writerow([data_label])
        writer.writerow([file_name, data_text, str(text_1), trialpit, data_label[0]])

    print("converted successfully")
    print("status = 0")


file_input = arguments["filename"]
file_output = "output" + os.sep + "noc_tp.csv"
detect_api_object(file_input, file_output)
