import cv2
import pytesseract
config = '-l eng --oem 1 --psm 3'

file_name_val ="crop\\crop_1.jpg"

im = cv2.imread(file_name_val)
text = pytesseract.image_to_string(im, config=config)
print("output=", text)