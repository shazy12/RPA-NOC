How to run -
1.Open this folder path terminal/cmd then type in cmd to run -> python tp_box.py -f "input/image1.jpg"
2.Replace your image name with 'image2.jpg' for image2 and so on..
3.In output folder you will get output in csv with name 'noc_tp.csv'