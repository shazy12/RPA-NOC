1. unzip the zipped folder.
2. open command prompt.
3. navigate to the project folder.
4. to run on Windows

python Image_LV.py -f "input/image1.jpg"
python Image_LV.py -f "input/image2.jpg"
python Image_LV.py -f "input/image3.jpg"
python Image_LV.py -f "input/image4.jpg"

5. to run on Linux

python3 Image_LV.py -f "input/image1.jpg"
python3 Image_LV.py -f "input/image2.jpg"
python3 Image_LV.py -f "input/image3.jpg"
python3 Image_LV.py -f "input/image4.jpg"

6. to run on program on vpn, public, office  
Image_lv_VPN.py run this python file when vpn is connected
Image_lv_Public.py run this file for public ip
Image_lv_Offie.py run this file for office ip

7. Output csv file will be saved in converted folder
   