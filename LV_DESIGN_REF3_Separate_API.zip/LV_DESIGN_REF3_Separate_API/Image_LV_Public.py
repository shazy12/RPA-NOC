import numpy as np
import urllib
import json
import cv2
import os
import requests
import cv2
import sys
import pytesseract
import glob
import argparse
import csv

arg = argparse.ArgumentParser()
arg.add_argument("-f", "--filename", required=True, help="name of the file\nFile should be in the Input Direcctory")
arguments = vars(arg.parse_args())
fetchDir = "fetchedImages"


def area_crop(file_name):
    if not len(os.listdir(fetchDir)) == 0:
        for file in glob.glob(fetchDir + os.sep + "*.jpg"):
            os.remove(file)
            print("[INFO] removing " + file + "from fetched Images directory.")

    requests.packages.urllib3.disable_warnings()
    # api_url_label = "https://10.150.20.61/powerai-vision/api/dlapis/92c84cad-3ab9-448a-bcad-2e208d1209aa"
    # api_url_label = "https://10.150.20.61/powerai-vision/api/dlapis/34215727-7346-4914-bafa-a5b0ec2a08c3"
    # api_url_label = "https://10.150.20.61/powerai-vision/api/dlapis/28864aef-1627-4482-8b83-087cd3880287"
    api_url_label = "https://195.229.90.114/powerai-vision/api/dlapis/13dd23d3-c33d-4b9b-abe4-266ecf2d682d"
    with open(file_name, 'rb') as f:
        s = requests.Session()
        r = s.post(api_url_label, files={'files': (file_name, f), 'confthre': '0.95'}, verify=False, timeout=10)
        data = json.loads(r.text)
        testdata = data["classified"]
        print(testdata)
        image = cv2.imread(file_name)
        count = 0
        for counter in range((len(testdata))):
            minX = int(testdata[counter].get('xmin'))
            minY = int(testdata[counter].get('ymin'))
            maxX = int(testdata[counter].get('xmax'))
            maxY = int(testdata[counter].get('ymax'))
            label = testdata[counter].get('label')
            print(label, minX, minY, maxX, maxY)

            # croppedImage = image[minY - 150:maxY + 190, minX - 150:maxX + 160]
            # filename = "fetchedImages" + os.sep + str(counter) + label + ".jpg"
            # print("filename", filename)
            # cv2.imwrite(filename, croppedImage)
    return label


def detect_api_object(file_name, file_output, label):
    image = cv2.imread(file_name)
    requests.packages.urllib3.disable_warnings()
    data = {"success": False}
    r = None

    # api_url_arrow = "https://195.229.90.114/powerai-vision/api/dlapis/2203c720-949d-4bfa-a671-cfc0c0f4ac34"
    # api_url_arrow = "https://10.150.20.61/powerai-vision/api/dlapis/de078269-7f80-4e1f-95b0-ee44caca14c7"
    api_url_arrow = "https://195.229.90.114/powerai-vision/api/dlapis/b4eda8fe-cbf6-49a0-b408-9d892a14495a"
    with open(file_name, 'rb') as f:
        s = requests.Session()
        r = s.post(api_url_arrow, files={'files': (file_name, f), 'confthre': '0.8'}, verify=False, timeout=10)

    import os
    label_text = " "
    data = json.loads(r.text)
    testdata = data["classified"]
    # print('data', data, type(data))
    # print(testdata)

    spotlight = "spotlight"

    for k, v in data.items():
        if v == spotlight:
            pass

    countofcropped = 0
    data_label = []
    # print("----->", len(testdata))
    for counter in range((len(testdata))):
        minX = int(testdata[counter].get('xmin'))  # (x1,y1,x2,y2)
        minY = int(testdata[counter].get('ymin'))
        maxX = int(testdata[counter].get('xmax'))
        maxY = int(testdata[counter].get('ymax'))
        label_arrow = testdata[counter].get('label')
        print(label_arrow, minX, minY, maxX, maxY)
        croppedImage = image[maxY:maxY+35, minX-30:maxX+40]
        # if arguments["filename"] == "input/image4.jpg":
        #     croppedImage = image[maxY - 3:maxY + 30, minX - 30:maxX + 40]
        #     if counter == 1:
        #         croppedImage = image[maxY - 3:maxY + 30, minX - 10:maxX + 40]
        file_name_val = "crop" + os.sep + "Crop_" + str(countofcropped) + ".jpg"
        print("file_name_val", file_name_val)
        cv2.imwrite(file_name_val, croppedImage)
        countofcropped += 1

        config = '-l eng --oem 1 --psm 3'

        im = cv2.imread(file_name_val)
        text = pytesseract.image_to_string(im, config=config)
        # print("Result from tesseract", text)
        # if len(text) > 20:
        #     text = text[0:19]
        data_label.append(text)
        # for i in data_label:
        # print(i)
        label_text += text + "\n"

    # print(data_label)

    # api_url = "https://195.229.90.114/powerai-vision/api/dlapis/926a9147-e428-4808-bb57-843e38b220e6"
    # api_url = "https://10.150.20.61/powerai-vision/api/dlapis/350ddf5d-2088-48a4-8c2e-093e77eeec7e"
    api_url = "https://195.229.90.114/powerai-vision/api/dlapis/e74c92ec-8aaa-4d4e-8266-d990cc02c6ee"
    # print(api_url)
    with open(file_name, 'rb') as f:
        s = requests.Session()
        r = s.post(api_url, files={'files': (file_name, f), 'confthre': '0.90'}, verify=False, timeout=10)
        # print(r.status_code)
        # print(r.text)

    import os
    chandelier = 0
    spotlight = 0
    data = json.loads(r.text)
    testdata = data["classified"]

    countofcropped = 0

    for key in testdata:
        print('key', key, type(key))
        for k, v in key.items():
            if k == 'label':
                # print("in k", k)
                if v == 'chandelier':
                    chandelier += 1
                    # print("in v(chandelier)", v)
                if v == 'spotlight':
                    spotlight += 1
                    # print("in v(spotlight)", v)

    total_spotlight = spotlight * 100
    total_chandelier = chandelier * 500
    total_watt = total_chandelier + total_spotlight
    context = {
        'result': data["result"],
        # 'image': 'data:image/jpeg;base64,' + textimage,
        'chandelier': chandelier,
        'spotlight': spotlight,
        'label_text': data_label,
        'total_chandelier': total_chandelier,
        'total_spotlight': total_spotlight,
        'total_watt': total_watt,

    }
    created = False
    if os.path.isfile(file_output):
        created = True
    with open(file_output, "a") as res:
        writer = csv.writer(res)
        if not created:
            writer.writerow(["RUN_ID", "DOC_ID", "TASKS", "LOCATION", "PARAM", "CIRCUIT REFRENCE", "COUNT", "WATT"])
        # print(arguments["filename"], file_name)
        # if arguments["filename"] == "input/image1.jpg" or "input/test1.jpg":
            print(label, len(data_label), data_label, chandelier, spotlight)
            writer.writerow([2, "300 VILLA", "Symbols", label, "Chandelier", data_label, chandelier,
                             chandelier * 500])
            writer.writerow([2, "300 VILLA", "Symbols", label, "Spotlight", "", spotlight,
                             spotlight * 100])
        else:
            print(label, len(data_label), data_label, chandelier, spotlight)
            writer.writerow([2, "300 VILLA", "Symbols", label, "Chandelier", data_label, chandelier,
                             chandelier * 500])
            writer.writerow([2, "300 VILLA", "Symbols", label, "Spotlight", "", spotlight,
                             spotlight * 100])
        # #
        # elif arguments["filename"] == "input/image2.jpg" or "input/test2.jpg":
        #     writer.writerow([2, "300 VILLA", "Symbols", "Living Room", "Chandelier", data_label[0], chandelier,
        #                      chandelier * 500])
        #     writer.writerow([2, "300 VILLA", "Symbols", "Living Room", "Spotlight", "", spotlight,
        #                      spotlight * 100])
        #
        # elif arguments["filename"] == "input/image3.jpg" or "input/test3.jpg":
        #     writer.writerow([2, "300 VILLA", "Symbols", "Bed Room", "Chandelier", data_label[0], chandelier,
        #                      chandelier * 500])
        #     writer.writerow([2, "300 VILLA", "Symbols", "Bed Room", "Spotlight", data_label[1], spotlight,
        #                      spotlight * 100])
        #
        # elif arguments["filename"] == "input/image4.jpg" or "input/test4.jpg":
        #     writer.writerow([2, "300 VILLA", "Symbols", "Master BedRoom", "Chandelier", data_label[0], chandelier,
        #                      chandelier * 500])
        #     writer.writerow([2, "300 VILLA", "Symbols", "Master BedRoom", "Spotlight", data_label[1], spotlight,
        #                      spotlight * 100])

    print("converted successfully")
    print("status = 0")


file_input = arguments["filename"]
# area_crop(file_input)
label = area_crop(file_input)
print("label global", label)
file_output = "converted" + os.sep + "LV_DESIGN_REF_3.csv"

detect_api_object(file_input, file_output, label)
