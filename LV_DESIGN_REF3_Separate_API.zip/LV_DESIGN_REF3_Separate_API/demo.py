import json
import requests
import cv2
import os
import glob

fetchDir = "fetchedImages"


def area_crop(file_name):
    if not len(os.listdir(fetchDir)) == 0:
        for file in glob.glob(fetchDir + os.sep + "*.jpg"):
            # print(file)
            os.remove(file)
            print("[INFO] removing " + file + "from fetched Images directory.")

    requests.packages.urllib3.disable_warnings()
    # api_url_label = "https://10.150.20.61/powerai-vision/api/dlapis/92c84cad-3ab9-448a-bcad-2e208d1209aa"
    api_url_label = "https://10.150.20.61/powerai-vision/api/dlapis/34215727-7346-4914-bafa-a5b0ec2a08c3"
    with open(file_name, 'rb') as f:
        s = requests.Session()
        r = s.post(api_url_label, files={'files': (file_name, f), 'confthre': '0.95'}, verify=False, timeout=10)
        data = json.loads(r.text)
        testdata = data["classified"]
        print(testdata)
        image = cv2.imread(file_name)
        count = 0
        for counter in range((len(testdata))):
            minX = int(testdata[counter].get('xmin'))
            minY = int(testdata[counter].get('ymin'))
            maxX = int(testdata[counter].get('xmax'))
            maxY = int(testdata[counter].get('ymax'))
            label = testdata[counter].get('label')
            print(label, minX, minY, maxX, maxY)

            # croppedImage = image[maxY:maxY + 50, minX - 40:maxX + 50]
            # croppedImage = image[minX - 100:maxX + 100, minY - 200:maxY + 200]
            # croppedImage = image[minY - 130:maxY + 190, minX - 150:maxX + 160]
            croppedImage = image[minY - 130:maxY+170, minX-70:maxX+70]
            filename = "fetchedImages" + os.sep + str(counter) + label + ".jpg"
            cv2.imwrite(filename, croppedImage)
            cv2.imshow(label, croppedImage)
            cv2.waitKey(0)


var = cv2.imread("input/2.jpg")
height, width = var.shape[:2]
print(height, width)
cv2.imshow("before", var)
cv2.waitKey(0)
area_crop("input/2.jpg")

