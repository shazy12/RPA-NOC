import cv2 as cv
import json
import numpy as np
import pandas as pd
import pickle
import os

list_data = []
list_of_numbers = [90, 26, 67, 47, 8]
list_of_contour_rect_coordinates = pd.read_csv("green"+os.sep+'list_filtered.csv', header=None, delimiter=',')
tuples = [tuple(x) for x in list_of_contour_rect_coordinates.values]
# print(tuples)
index_of_inner_contours = []
# print(tuples)
img = np.zeros(shape=[2000, 2000, 3], dtype=np.uint8)


def generate_and_save_JSON(tuples):
    for rectangle in tuples:
        # print(rectangle, rectangle[0], rectangle[1], rectangle[2], rectangle[3], rectangle[4], tuples.index(
        # rectangle))
        list_data.append(
            [int(rectangle[0][1:]), int(rectangle[1]), int(rectangle[2]), int(rectangle[3]), int(rectangle[4]),
             tuples.index(rectangle) in index_of_inner_contours])


def list_inner_contour(tuples):
    for rectangle in tuples:
        index_of_rectangle = tuples.index(rectangle)
        # print(index_of_rectangle)
        i = 0
        while i < len(tuples):
            if i != index_of_rectangle:
                if rectangle[1] > tuples[i][1] and rectangle[2] > tuples[i][2] \
                        and rectangle[3] < tuples[i][3] and rectangle[4] < tuples[i][4]:
                    index_of_inner_contours.append(index_of_rectangle)
                # print("index_of_inner_contours ", index_of_inner_contours)
            i += 1

    return True


def slice_on_custom_list_of_indices(tuples, list_of_indices):
    sliced_tuple = []
    for index in list_of_indices:
        sliced_tuple.append(tuples[index])
    return sliced_tuple


list_inner_contour(tuples)
# plot_rectangles(input,tuples,(0,255,0))
tuple_of_inner_contours = slice_on_custom_list_of_indices(tuples, index_of_inner_contours)
# plot_rectangles(input,tuple_of_inner_contours,(0,0,255))
generate_and_save_JSON(tuples)

inner_contours = []
outer_contours = []
# print('list_data', list_data)

for i in list_data:
    if not i[5]:
        inner_contours.append(i)
    else:
        outer_contours.append(i)

# for i in inner_contours:
#     print(i)
#
# for j in outer_contours:
#     print(j)

df = pd.DataFrame(data=list_data, columns=['index', 'min_x', 'min_y', 'max_x', 'max_y', 'is_contour_true'])
df.to_json("green"+os.sep+'A1.json')
