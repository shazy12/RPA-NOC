1. unzip the zipped folder.
2. open command prompt.
3. navigate to the project folder.
4. to run on Windows

python finding_boxes.py -f "input/image1.jpg"
OR
python finding_boxes.py -f "input/image2.jpg"
OR
python finding_boxes.py -f "input/image3.jpg"

5. to run on Linux
python finding_boxes.py -f "input/image1.jpg"
OR
python finding_boxes.py -f "input/image2.jpg"
OR
python finding_boxes.py -f "input/image3.jpg"


6. you will get output in converted directory

note:- pytesseract, opencv, pandas

on windows -

pip install opencv-contrib-python
pip install opencv-python
pip install pandas
Kindly install tesseract-ocr from folowing link (windows os.64bit)
https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-v5.0.0-alpha.20191030.exe
install tesseract-ocr on windows in the below path
c:/tesseract-ocr
set  system environment variable :
    i)open file explorer
    ii)right click on this pc select properties
    iii)click on advanced system settings click on environments button variable
    iv)edit path of system variable and add following path
        append c:/tesseract-ocr  to the system path varaible
    v)create new user environment varaible as below
        TESSDATA_PREFIX = "c:/tesseract-ocr/tessdata"
       kindly restart the command prompt

on ubuntu

pip3 install opencv-contrib-python
pip3 install opencv-python
pip3 install pandas


