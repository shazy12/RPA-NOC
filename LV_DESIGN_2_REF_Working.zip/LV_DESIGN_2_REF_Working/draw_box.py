from inner_counter_box import inner_contours
import cv2

print(inner_contours)

# image = cv2.imread("input\\image2.jpg")
# image = cv2.imread('input\\image2.jpg', cv2.IMREAD_ANYCOLOR)
# image = cv2.resize(image, (905, 1280))
image = cv2.imread('input\\oo10.jpg', cv2.IMREAD_ANYCOLOR)
# cv2.imshow('image', image)
# cv2.waitKey(10000)
height, width = image.shape[:2]
print(height, width)

countofcropped = 0
for cnt in inner_contours:
    print(cnt[1], cnt[2], cnt[3], cnt[4])
    xmin = cnt[1]
    ymin = cnt[2]
    xmax = cnt[3]
    ymax = cnt[4]
    # print(image[:3])
    croppedImage = image[ymin:ymax, xmin:xmax]
    countofcropped += 1
    cv2.imwrite("contour\\Cnt2_" + str(countofcropped) + ".jpg", croppedImage)

print('done')
