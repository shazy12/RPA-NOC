import cv2
import numpy as np
import csv
import copy
import argparse
import os
arg = argparse.ArgumentParser()
arg.add_argument("-f", "--filename", required=True, help="name of the file\nFile should be in the Input Direcctory")
arguments = vars(arg.parse_args())

font = cv2.FONT_HERSHEY_COMPLEX
print(arguments["filename"])
img = cv2.imread(arguments["filename"], cv2.IMREAD_ANYCOLOR)
img = cv2.resize(img, (1280, 905))
img1 = copy.deepcopy(img)

# input
# input = cv2.imread("shapes.jpg", cv2.IMREAD_GRAYSCALE)
for i in range(img.shape[0]):
    for j in range(img.shape[1]):
        if img[i][j][0] > 50 or img[i][j][2] > 50 or img[i][j][1] < 127:
            img[i][j][0] = 255
            img[i][j][2] = 255
            img[i][j][1] = 255
        # if input[i][j][1] > 127 and input[i][j][1] > input[i][j][0] and input[i][j][1] > input[i][j][2]:
        #     input[i][j][0] = 0
        #     input[i][j][2] = 0
        #     input[i][j][1] = 255

# cv2.imshow("input image after manual transformation", input)
# cv2.waitKey()
b, g, r = cv2.split(img)
# cv2.imshow("g image", g)
# cv2.waitKey(1)
# cv2.imshow("b image", b)
# cv2.waitKey(0)
# cv2.imshow("r image", r)
# cv2.waitKey(0)

blur = cv2.GaussianBlur(g, (5, 5), 0)
ret3, th3 = cv2.threshold(blur, 240, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
# cv2.imshow("Threshold3", th3)
# cv2.waitKey(0)
gray = th3
edges = cv2.Canny(gray, 50, 150, apertureSize=3)
# cv2.imwrite('edges-50-150.jpg', edges)
minLineLength = 5
lines = cv2.HoughLinesP(image=edges, rho=2, theta=np.pi / 180, threshold=50, lines=np.array([]),
                        minLineLength=minLineLength, maxLineGap=40)

a, b, c = lines.shape
for i in range(a):
    cv2.line(gray, (lines[i][0][0], lines[i][0][1]), (lines[i][0][2], lines[i][0][3]), (0, 0, 255), 2, cv2.LINE_AA)

# cv2.imshow("Show gray ", gray)
# cv2.waitKey(0)

_, threshold = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)
# cv2.imshow("Threshold", threshold)
# cv2.waitKey(0)

contours, _ = cv2.findContours(threshold, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
countofcropped = 0
list = ''
list_filtered = []
listcount = 0
for cnt in contours:
    # print(type(cnt), cnt)
    approx = cv2.approxPolyDP(cnt, 0.01 * cv2.arcLength(cnt, True), True)
    if len(approx) > 3:
        (startCol, startRow, w, h) = cv2.boundingRect(approx)
        endCol = startCol + w
        endRow = startRow + h

        # x_values = approx.min(axis=2, out=None, keepdims=True, where=True)
        # y_values = approx.max(axis=2, out=None, keepdims=True, where=True)
        # startRow = int(y_values.min())
        # startCol = int(x_values.min())
        # endRow = int(y_values.max())
        # endCol = int(x_values.max())
        # endRow = approx[len(approx)-2][0][1]
        # endCol = approx[len(approx)-2][0][0]
        Area = abs(endCol - startCol) * abs(endRow - startRow)

        list = list + str(listcount) + ',' + str(startCol) + ',' + str(startRow) + ',' + str(endCol) + ',' + str(
            endRow) + ',' + str(Area) + '\n'
        croppedImage = img1[startRow:endRow, startCol:endCol]
        listcount += 1
        if Area > 700:
            list_filtered.append([countofcropped, startCol, startRow, endCol, endRow, Area])
            # print(countofcropped)
            x = approx.ravel()[0]
            y = approx.ravel()[1]
            countofcropped += 1

            # cv2.putText(input, "Rectangle", (startCol, startRow), font, 1, (0))
            # cv2.imshow("shapes_" + str(countofcropped), input)
            # cv2.waitKey(0)
            cv2.drawContours(img, [approx], contourIdx=0, color=(0, 255, 0), thickness=1)

            # cv2.imshow("draw contour" + "" + str(countofcropped), input)
            # cv2.waitKey(0)

            cv2.imwrite("green"+os.sep+"cnt_" + str(countofcropped) + ".jpg", croppedImage)

with open("green" +os.sep+ "list.csv", "w") as text_file:
    text_file.write(list)
with open("green"+os.sep+"list_filtered.csv", 'w') as resultFile:
    for i in range(len(list_filtered)):
        resultFile.write(str(list_filtered[i]))
        if i < (len(list_filtered) - 1):
            resultFile.write('\n')
    # wr = csv.writer(resultFile, dialect='excel')
    # # byte_list = str.encode(list_filtered)
    # wr.writerows(bytearray(list_filtered))
for i in range(len(list_filtered)):
    cv2.putText(img1, str(i), (list_filtered[i][1], list_filtered[i][2]), font, 1, 0)
    cv2.rectangle(img1, (list_filtered[i][1], list_filtered[i][2]), (list_filtered[i][3],
                                                                     list_filtered[i][4]), (0, 255, 0), 1)
# cv2.imwrite("extracted_image.jpg", img1)
# cv2.destroyAllWindows()

from inner_counter_box import inner_contours
import cv2

font = cv2.FONT_HERSHEY_COMPLEX

img = cv2.imread('input\\sample3.jpg', cv2.IMREAD_ANYCOLOR)
# img = cv2.imread(arguments["filename"], cv2.IMREAD_ANYCOLOR)
img = cv2.resize(img, (4963, 3509))
height, width = img.shape[:2]
# print(height, width)

countofcropped = 0
for cnt in inner_contours:
    # print(cnt[1], cnt[2], cnt[3], cnt[4])
    xmin = round(cnt[1] * 3.88)
    ymin = round(cnt[2] * 3.88)
    xmax = round(cnt[3] * 3.88)
    ymax = round(cnt[4] * 3.88)
    # print(xmin, xmax, ymin, ymax)
    # print(image[:3])
    croppedImage = img[ymin:ymax, xmin:xmax]
    countofcropped += 1
    cv2.imwrite("contour\\Cnt23_" + str(countofcropped) + ".jpg", croppedImage)

# print('done')

import cv2
import sys
import pytesseract
import glob
import os

try:
    config = '-l eng --oem 1 --psm 3'

    im = glob.glob("contour\\*.jpg")
    # print(im)

    # input = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    # thresh, im_bw = cv2.threshold(input, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    # os.remove("text.csv")
    if os.path.isfile("converted" + os.sep +arguments["filename"][6:-4] + ".csv"):
        os.remove("converted" + os.sep +arguments["filename"][6:-4] + ".csv")

    with open("converted" + os.sep +arguments["filename"][6:-4] + ".csv", "a") as cs:
        writer = csv.writer(cs)
        writer.writerow(["Extracted Text From Images"])
        count = 0
        for i in im:
            param = ""
            text = pytesseract.image_to_string(i, config=config)
            # print(count, text)
            # if count == 0:
            #     param = "Breaker"
            # if count == 1:
            #     param = "Breaker1"
            # if count == 2:
            #     param = "cable"
            # if count == 3:
            #     param = "TP"
            # if count == 5:
            #     param = "ECC"
            # count += 1
            #
            # if param == "":
            #     continue
            writer.writerow([text])
    print('sucessfully created')
    print('status=0')

except:
    print('failed')
    print('status=1')
    raise
