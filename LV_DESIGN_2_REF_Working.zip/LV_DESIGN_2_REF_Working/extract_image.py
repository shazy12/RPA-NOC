import numpy as np
import csv
import io
from PIL import Image
import pytesseract
from wand.image import Image as wi
from pytesseract import Output
import cv2


img_path = 'contour/Cnt23_1.jpg'
pdfImg = wi(filename=img_path, resolution=100)
# pdfImg = cv2.imread(img_path)
# pdfImg = pdf.convert('jpg')
j = 1
for img in pdfImg.sequence:
    page = wi(image=img)
    page.save(filename=str(j) + ".jpg")
    img1 = cv2.imread(str(j) + ".jpg")

    d = pytesseract.image_to_data(img1, output_type=Output.DICT)
    n_boxes = len(d['level'])
    print(n_boxes)
    for i in range(n_boxes):
        (x, y, w, h) = (d['left'][i], d['top']
        [i], d['width'][i], d['height'][i])
        print((x, y, w, h))
        cv2.rectangle(img1, (x, y), (x + w, y + h), (0, 255, 0), 2)

    cv2.imwrite(str(j) + ".jpg", img1)

    cv2.waitKey(0)
    j += 1
