import cv2
import sys
import pytesseract
import glob

config = '-l eng --oem 1 --psm 3'

im = glob.glob("contour\\*.jpg")
print(im)

# input = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
# thresh, im_bw = cv2.threshold(input, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
for i in im:
    print(i)
    text = pytesseract.image_to_string(i, config=config)
    print(text)
# cv2.imshow('image', input)
# cv2.waitKey(0)
# cv2.imshow('image', im_bw)
# cv2.waitKey(0)
