from inner_counter_box import inner_contours
import cv2

# print(inner_contours)
# image = cv2.imread('input\\image2.jpg', cv2.IMREAD_ANYCOLOR)
font = cv2.FONT_HERSHEY_COMPLEX

img = cv2.imread('input\\image2.jpg', cv2.IMREAD_ANYCOLOR)
# input = cv2.resize(input, (1280,905))
# b, g, r = cv2.split(input)
# for i in range(input.shape[0]):
#     for j in range(input.shape[1]):
#         if input[i][j][1] > 165 and input[i][j][0] < 5 and input[i][j][2] < 5:
#             input[i][j][0] = 255
#             input[i][j][2] = 255
#             input[i][j][1] = 255
#         # else:
#         #     input[i][j][0] = 0.2 * input[i][j][0]
#         #     input[i][j][2] = 0.2 * input[i][j][2]
#         #     input[i][j][1] = 0.2 * input[i][j][1]
#
#
# cv2.imshow("input image after manual transformation", input)
# cv2.waitKey(0)


# cv2.imshow('image', image)
# cv2.waitKey(10000)
height, width = img.shape[:2]
print(height, width)

countofcropped = 0
for cnt in inner_contours:
    # print(cnt[1], cnt[2], cnt[3], cnt[4])
    xmin = round(cnt[1] * 3.88)
    ymin = round(cnt[2] * 3.88)
    xmax = round(cnt[3] * 3.88)
    ymax = round(cnt[4] * 3.88)
    print(xmin, xmax, ymin, ymax)
    # print(image[:3])
    croppedImage = img[ymin:ymax, xmin:xmax]
    countofcropped += 1
    cv2.imwrite("contour\\Cnt23_" + str(countofcropped) + ".jpg", croppedImage)

print('done')
