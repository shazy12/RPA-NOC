import pdftables_api
import argparse
import os
import csv
import bs4 as bs
import urllib.request

arg = argparse.ArgumentParser()
arg.add_argument("-f", "--filename", required=True, help="name of the file\nFile should be in the Input Direcctory")
arguments = vars(arg.parse_args())


def con_pdf2xml(file_name):
    # print("[INFO] arguments passed =====>", file_name)
    try:
        # input_file = arguments["filename"]
        output_file_xml = "convert" + os.sep + file_name[6:-4] + ".xml"

        c = pdftables_api.Client('b33hbon0fk20')
        c.xml(file_name, output_file_xml)
        # print('[INFO] convert to xml.')
        return 0, output_file_xml
    except:
        print('[INFO] convert failure.')
        return 1, "Error"


tosearch = ['owner:-', 'area', 'plot', 'total', 'maximum', 'diversity', 'outgoing:-', 'incomer', 'cablesize',
            'DB-1(G/F)', 'SPARE*', 'LOCATION']
try:
    success, xml_file = con_pdf2xml(arguments["filename"])
    output_file = "converted" + os.sep + xml_file[8:-4] + ".csv"
    xml = open(xml_file, "r+")
    outfile = open(output_file, 'a')
    writer = csv.writer(outfile)
    writer.writerow(["RUN_ID", "DOC_ID", "TASKS", "PARAM", "VALUE"])
    soup = bs.BeautifulSoup(xml, 'lxml')
    table = soup.table
    table_rows = table.find_all('tr')

    for tr in table_rows:
        td = tr.find_all('td')
        row = [i.text for i in td]

        for i in row:
            for j in tosearch:
                if i.lower() == j.lower():
                    if j == 'area':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i),
                                         str(row[idx + 4]) + " " + str(row[idx + 5]) + " " + str(row[idx + 6])])
                    elif j == 'LOCATION':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i) + " OF MDB: ",
                                         str(row[idx + 4]) + " " + str(row[idx + 5]) + " " + str(row[idx + 6])])
                    elif j == 'owner:-':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i), str(row[idx + 2])])
                    elif j == 'plot':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i), str(row[idx + 2])])
                    elif j == 'total':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i) + " " + str(row[idx + 1]) + " " + str(row[idx + 4]),
                             str(row[idx + 5])])
                    elif j == 'maximum':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i) + " " + str(row[idx + 1]) + " " + str(row[idx + 4]),
                             str(row[idx + 5])])
                    elif j == 'diversity':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i) + " " + str(row[idx + 1]), str(row[idx + 4])])
                    elif j == 'outgoing:-':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i) + " spare", str(row[idx + 8])])
                    elif j == 'incomer':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i) + " ECC", str(row[idx + 12])])
                    elif j == 'incomer':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i) + " ECC", str(row[idx + 12])])
                        writer.writerow([1, "1_125", "NOC", str(i) + " Y ", str(row[idx + 15])])
                        writer.writerow([1, "1_125", "NOC", str(i) + " R ", str(row[idx + 13])])
                        writer.writerow([1, "1_125", "NOC", str(i) + " B ", str(row[idx + 17])])
                        writer.writerow([1, "1_125", "NOC", str(i) + " TOTAL ", str(row[idx + 18])])
                        writer.writerow(
                            [str(i) + " CABLE TYPE", str(row[idx + 9]) + " " + str(row[idx + 10])])
                        writer.writerow([1, "1_125", "NOC", str(i) + " MCCB", str(row[idx + 5])])
                        writer.writerow([1, "1_125", "NOC", str(i) + " FAULT BODY", str(row[idx + 7])])
                    elif j == 'DB-1(G/F)':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", str(i) + " MCCB  ", str(row[idx + 5])])
                        writer.writerow([1, "1_125", "NOC", str(i) + " FAULT DUTY  ", str(row[idx + 7])])
                        writer.writerow([1, "1_125", "NOC", str(i) + " CABLE TYPE  ", str(row[idx + 8])])
                        writer.writerow([1, "1_125", "NOC", str(i) + " ECC  ", str(row[idx + 10])])

                    elif j == 'SPARE*':
                        outfile = open(output_file, 'a')
                        writer = csv.writer(outfile)
                        idx = row.index(i)
                        writer.writerow([1, "1_125", "NOC", "Outgoing " + str(i) + " MCCB  ", str(row[idx + 5])])
                        writer.writerow([1, "1_125", "NOC", "Outgoing " + str(i) + " FAULT DUTY  ", str(row[idx + 7])])
                        writer.writerow([1, "1_125", "NOC", "Outgoing " + str(i) + " CABLE TYPE  ", str(row[idx + 8])])
                        writer.writerow([1, "1_125", "NOC", "Outgoing " + str(i) + " CABLE SIZE  ", str(row[idx + 9])])
                        writer.writerow([1, "1_125", "NOC", "Outgoing " + str(i) + " ECC  ", str(row[idx + 15])])
                        writer.writerow([1, "1_125", "NOC", "Outgoing " + str(i) + " R  ", str(row[idx + 16])])
                        writer.writerow([1, "1_125", "NOC", "Outgoing " + str(i) + " Y  ", str(row[idx + 17])])
                        writer.writerow([1, "1_125", "NOC", "Outgoing " + str(i) + " B  ", str(row[idx + 18])])
                        writer.writerow([1, "1_125", "NOC", "Outgoing " + str(i) + " TOTAL  ", str(row[idx + 19])])
    xml.close()
    print('Successfully converted')
    print('Status = 0')


except:
    print('Conversion failed')
    print('Status = 1')
    raise
