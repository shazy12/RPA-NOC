1. unzip the zip folder.
2. put your pdf in the input directory [IMP]
3. go to the command prompt
4. go to the project directory in the command prompt.
5. to convert your pdf simply run this command
In Windows (python api.py -f "input/<yourpdf>.pdf")
In Linux (python3 api.py -f "input/<yourpdf>.pdf")


6. XML file will be converted in the convert Directory.
7. CSV file will be converted in the converted Directory.